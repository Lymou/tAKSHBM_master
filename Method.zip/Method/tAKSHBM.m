function [val,time,Xk,EL]= tAKSHBM(A,B,Xn,kmax,TOL,bs)
X0=zeros(size(Xn));
[~,~,X1]= tRAK_a1(A,B,Xn,1,TOL,bs,1);
N1=size(A,1);
tau=floor(N1/bs);
 T=Pcolumn(tau,N1);
AT=tran(A);
ts=tic;
for iter=1:kmax
    time(iter)=toc(ts);
    VAL=log10(tRSE(X0,Xn));
    val(iter)=VAL;
    p=randperm(size(T,2),1);
    tauik=T{p};
    EL(iter)=p;
%     tauik=T{mod(iter,size(T,2))+1};
    Er=X1-X0;
    ErF=sum(Er.^2,[1,2,3]);
    Sr=tprod(A(tauik,:,:),X1)-B(tauik,:,:);
    SrF=sum(Sr.^2,[1,2,3]);
    Fr=tprod(tran(A(tauik,:,:)),Sr);
    FrF=sum(Fr.^2,[1,2,3]);
    Low=FrF*ErF-tinner(Fr,Er)^2;
    alphak=(ErF*SrF)/Low;
    betak=(tinner(Fr,Er)*SrF)/Low;
    Xk=X1-alphak*Fr+betak*Er;
    if VAL<TOL
        break
    end
    X0=X1;
    X1=Xk;
end

end
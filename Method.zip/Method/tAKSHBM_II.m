function [val,time,X]= tAKSHBM_II(A,B,Xe,kmax,TOL,bs,EL)
    [val,~,X1]= tRAK_a1_II(A,B,Xe,1,TOL,bs);
    
    X0=zeros(size(Xe));
    [N1,~,N3]=size(A);
    tau=floor(N1/bs);
    T=Pcolumn(tau,N1);
    
    A_fft=fft(A,[],3);
    X0_fft=fft(X0,[],3);
    X1_fft=fft(X1,[],3);
    Xe_fft=fft(Xe,[],3);
    B_fft=fft(B,[],3);
    ts=tic;
    for iter=1:kmax
        time(iter)=toc(ts);
        XF=ifft(X0_fft,[],3);
        Xtr=ifft(Xe_fft,[],3);
        VAL=log10(tRSE(XF,Xtr));
        val(iter)=VAL;
        if iter<=length(EL);tauk=T{EL(iter)};else;tauk=T{randperm(length(T),1)};end
        for k=1:N3
            R=A_fft(tauk,:,k)*X1_fft(:,:,k)-B_fft(tauk,:,k);
            RF=norm(R,'fro')^2;
            FS=A_fft(tauk,:,k)'*(-R);
            FSF=norm(FS,'fro')^2;
            S=X1_fft(:,:,k)-X0_fft(:,:,k);
            SF=norm(S,'fro')^2;
            L1=tinner(-FS,S);
            
            LOW=FSF*SF-L1^2;
            alphak=(SF*RF)/LOW;
            betak=(L1*RF)/LOW;
            Xk_fft(:,:,k)=X1_fft(:,:,k)+alphak*FS+betak*S;
        end
        if VAL<TOL,break;end
        X0_fft=X1_fft;
        X1_fft=Xk_fft; 
    end
    X=ifft(Xk_fft,[],3);
end
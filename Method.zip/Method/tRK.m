function [val,time,X]= tRK(A,B,Xn,kmax,TOL,eta)
    X=zeros(size(Xn));
    N1=size(A,1);

    for i=1:1
        V(i)=norm(bcirc(A(i,:,:)),2)^2/(sum(sum(sum(A(i,:,:).^2))));
    end
    zeta=max(V);

    ts=tic;
    for iter=1:kmax
        time(iter)=toc(ts);
        VAL=log10(tRSE(X,Xn));
        val(iter)=VAL;
        ik=randperm(N1,1);
        alpha=eta/zeta;
        Up=alpha/tinner(A(ik,:,:),A(ik,:,:));
        Low=tprod(tran(A(ik,:,:)),B(ik,:,:)-tprod(A(ik,:,:),X));
        X=X+Up*Low;
        if VAL<TOL
            break
        end
    end
end
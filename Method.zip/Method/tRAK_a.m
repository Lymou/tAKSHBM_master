function [val,time,X]= tRAK_a(A,B,Xn,kmax,TOL,bs,omega)
X=zeros(size(Xn));
N1=size(A,1);
tau=floor(N1/bs);

ts=tic;
for iter=1:kmax
    time(iter)=toc(ts);
%     VAL=ssim(X,Xn);
    VAL=log10(tRSE(X,Xn));
    val(iter)=VAL;
    T=Pcolumn(tau,N1);
    tk=T{randperm(length(T),1)};
    Rk=B(tk,:,:)-tprod(A(tk,:,:),X);
    V1=tran(A(tk,:,:));
    V2=Rk;
    V3=sum(sum(sum(Rk.^2)));
    V5=sum(sum(sum(tprod(V1,V2).^2)));
    T1=V3/V5;
    X=X+omega*T1*tprod(V1,Rk);
    if VAL<TOL
        break
    end
end
end
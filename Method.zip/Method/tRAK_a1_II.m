function [val,time,X]= tRAK_a1_II(A,B,Xe,kmax,TOL,bs)
X0=zeros(size(Xe));
[N1,~,N3]=size(A);
tau=floor(N1/bs);
T=Pcolumn(tau,N1);
A_fft=fft(A,[],3);
X0_fft=fft(X0,[],3);
Xe_fft=fft(Xe,[],3);
B_fft=fft(B,[],3);
ts=tic;
for iter=1:kmax
    time(iter)=toc(ts);
    XF=ifft(X0_fft,[],3);
    Xtr=ifft(Xe_fft,[],3);
    VAL=log10(tRSE(XF,Xtr));
    val(iter)=VAL;
    tauk=T{1};
    for k=1:N3
        R0=B_fft(tauk,:,k)-A_fft(tauk,:,k)*X0_fft(:,:,k);
        R0F=norm(R0,'fro')^2;
        Low=A_fft(tauk,:,k)'*R0;
        LowF=norm(Low,'fro')^2;
        Ladap=R0F/LowF;
        X0_fft(:,:,k)=X0_fft(:,:,k)+Ladap*Low;
    end
    if VAL<TOL,break;end
end
X=ifft(X0_fft,[],3);
end
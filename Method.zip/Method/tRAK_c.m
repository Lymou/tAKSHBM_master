function [val,time,X]= tRAK_c(A,B,Xn,kmax,TOL,bs,eta)
    X=zeros(size(Xn));
    N1=size(A,1);
    tau=floor(N1/bs);

    T=Pcolumn(tau,N1);
    for i=1:length(T)
        tk=T{i};
        V(i)=norm(bcirc(A(tk,:,:)),2)^2/((sum(A(tk,:,:).^2,[1,2,3])));
    end
    zeta=max(V);

    ts=tic;
    for iter=1:kmax
        time(iter)=toc(ts);
        VAL=log10(tRSE(X,Xn));
        val(iter)=VAL;
        tk=T{randperm(length(T),1)};
        Rk=B(tk,:,:)-tprod(A(tk,:,:),X);
        alpha=eta/max(V);
        V1=alpha/(sum(sum(sum(A(tk,:,:).^2))));
        V2=tprod(tran(A(tk,:,:)),Rk);
        X=X+V1*V2;
        if VAL<TOL
            break
        end
    end
end